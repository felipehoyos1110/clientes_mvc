# Clientes MVC

![technology java](https://img.shields.io/badge/technology-java-blue.svg)

Implementación de un proyecto de software aplicando el patrón Modelo Vista Controlador (MVC) .

## Contenido

Script de creación de tabla
```
create table cliente(
id int auto_increment primary key,
Nombres varchar(100),
Correo varchar(100),
Telefono varchar(100)
)
```

IMPLEMENTACIÓN DE UN PROYECTO DE SOFTWARE

LUIS FELIPE HOYOS LONDOÑO

PLATAFORMAS DE DESARROLLO DE SOFTWARE

SEMANA 3

PROFESOR: FRANK JAIRO CASTILLO PADILLA

08-Febrero-2023
